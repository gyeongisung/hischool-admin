import Pagination from "react-js-pagination";
import { PagiWrap } from "../../styles/PagiStyle";

const NoticePaging = ({
  currentPage,
  setCurrentPage,
  totalCount,
  last4Important,
}) => {
  let itemsCount = 10;
  if (last4Important.length === 0) {
    itemsCount = 14;
  } else if (last4Important.length === 1) {
    itemsCount = 13;
  } else if (last4Important.length === 2) {
    itemsCount = 12;
  } else if (last4Important.length === 3) {
    itemsCount = 11;
  } else if (last4Important.length === 4) {
    itemsCount = 10;
  }

  return (
    <PagiWrap>
      <Pagination
        activePage={currentPage}
        itemsCountPerPage={itemsCount}
        totalItemsCount={totalCount}
        pageRangeDisplayed={5}
        prevPageText={"‹"}
        nextPageText={"›"}
        onChange={setCurrentPage}
      />
    </PagiWrap>
  );
};

export default NoticePaging;
