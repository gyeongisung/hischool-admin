import React from 'react'

const LifeRecord = () => {
  return (
    <div>LifeRecord</div>
  )
}

export default LifeRecord